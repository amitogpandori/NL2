module hostpanel

go 1.26.0

require (
	github.com/pkg/sftp v1.13.11
	golang.org/x/crypto v0.58.0
	golang.org/x/net v0.61.0
	golang.org/x/sys v0.49.0
)

require (
	github.com/kr/fs v0.1.0 // indirect
	golang.org/x/text v0.43.0 // indirect
)
